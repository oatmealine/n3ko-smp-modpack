<div align="center">
  
# Dragon Origin

> Datapack port (and slight tweak) of the Dragon Origin from Proman68's Mythical Origins Addon (1.18.1, Origin v1.3.2)

</div>

Check out the original addon [here](https://www.curseforge.com/minecraft/mc-mods/mythical-origins)!

## Requirements:

- [Origins](https://modrinth.com/mod/origins)

## Powers:

### ➕ Winged
You are born with an elytra attatched to your back.

### ➕ Reborn Magic
The dragon egg emits some sort of familiar magic, making you stronger near it.

### ➕ Resistant Skin
Your resistant skin gives you an additional 3 hearts.

### ➕ Lava Vision
You are able to see better while submerged in lava.

### ➕ Sharp Claws
Your extremely sharp claws allow you to deal 2.0x more damage on unarmed attacks.

### ➕ Sturdy Scales
Your scales make you have natural permanent armor points.

### ➖ Uncomfortable Armor
Armor with protecton lower than diamond is uncomfortable, so you are unable to wear it.

### ➖ Exhausting Heat
The heat the nether produces is too much for you to handle, making you more hungry.

### ➖ Unwieldy
You are unable to use a shield.

### ➖ Carnivore
You are a carnivore, so you can only eat meat.

### ➖ Hydrophobia
You take damage over time while in contact with water.

### ➖ Large Appetite
You exhaust much quicker than others, thus requiring you to eat more.